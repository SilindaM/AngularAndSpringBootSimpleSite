export class User {
    id:number;
    name:String;
    surname:String;
    email:String;
}
